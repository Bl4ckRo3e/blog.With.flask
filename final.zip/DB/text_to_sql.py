import sqlite3

# Open the text file for reading
with open('data.txt', 'r') as file:
    data = file.readlines()

# Connect to the SQLite database
conn = sqlite3.connect('example.db')
cursor = conn.cursor()

# Create a table in the database if it does not already exist
cursor.execute("CREATE TABLE IF NOT EXISTS my_table (id INTEGER PRIMARY KEY, value TEXT)")

# Read each line from the text file and insert into the database
for line in data:
    cursor.execute("INSERT INTO my_table (value) VALUES (?)", (line.strip(),))

# Commit the changes to the database
conn.commit()

# Close the cursor and the database connection
cursor.close()
conn.close()
