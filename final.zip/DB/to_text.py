import csv

# Define the paths to the CSV files and the output text file
file1_path = 'images.csv'
# file2_path = 'file2.csv'
output_file_path = 'images.txt'

# Open the output text file in write mode
with open(output_file_path, 'w') as output_file:
    # Open the first CSV file and read its rows
    with open(file1_path, 'r') as file1:
        csv_reader = csv.reader(file1)
        for row in csv_reader:
            # Write each row to the output text file
            output_file.write(','.join(row) + '\n')

    # # Open the second CSV file and read its rows
    # with open(file2_path, 'r') as file2:
    #     csv_reader = csv.reader(file2)
    #     for row in csv_reader:
    #         # Write each row to the output text file
    #         output_file.write(','.join(row) + '\n')

print('Data from the CSV files has been written to the output text file.')
