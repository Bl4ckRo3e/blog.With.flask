import random

questions = [
    {"question": "What is the capital of France?", "answer": "Paris"},
    {"question": "What is the largest ocean?", "answer": "Pacific"},
    {"question": "What is the tallest mountain in the world?", "answer": "Mount Everest"},
    {"question": "What is the currency of Japan?", "answer": "Yen"},
    {"question": "What is the largest mammal?", "answer": "Blue Whale"},
    {"question": "What is the chemical symbol for gold?", "answer": "Au"},
    {"question": "What is the longest river in the world?", "answer": "Nile"},
    {"question": "What is the largest desert on Earth?", "answer": "Sahara"},
    {"question": "What is the hottest continent?", "answer": "Africa"},
    {"question": "What is the largest planet in our solar system?", "answer": "Jupiter"},
    {"question": "What is the largest country by landmass?", "answer": "Russia"},
    {"question": "What is the fastest land animal?", "answer": "Cheetah"},
    {"question": "What is the national flower of Japan?", "answer": "Cherry Blossom"},
    {"question": "What is the smallest country in the world?", "answer": "Vatican City"},
    {"question": "What is the most populated country in the world?", "answer": "China"},
    {"question": "What is the largest bird in the world?", "answer": "Ostrich"},
    {"question": "What is the coldest continent on Earth?", "answer": "Antarctica"},
    {"question": "What is the hardest natural substance on Earth?", "answer": "Diamond"},
    {"question": "What is the national animal of Australia?", "answer": "Kangaroo"},
    {"question": "What is the largest lake in Africa?", "answer": "Lake Victoria"}
]

score = 0

for i in range(20):
    random_question = random.choice(questions)
    print("Question", i+1, ":", random_question["question"])
    user_answer = input("Your answer: ")
    
    if user_answer.lower() == random_question["answer"].lower():
        print("Correct!")
        score += 5
    else:
        print("Incorrect! The correct answer is:", random_question["answer"])

print("\nEnd of quiz. Your score is:", score, "%")
